# Website Youfi Systems

## Inhoud
```
index.html              de volledige website (8 pagina's)
youfi-og-image.png      deelafbeelding voor WhatsApp en LinkedIn
img/                    11 afbeeldingen (screenshots en productbeelden)
```

Upload alle bestanden mét de map `img/` naar de webroot.
`index.html` is automatisch de startpagina.

## Nog te doen voor livegang

### 1. Contactformulier activeren  (1 minuut)
Zonder dit opent het formulier het mailprogramma van de bezoeker,
in plaats van de mail zelf te versturen.

1. Ga naar https://web3forms.com
2. Vul `info@youfisystems.nl` in bij "Create Access Key"
3. U ontvangt een sleutel per mail
4. Zoek in `index.html` naar `const FORM_KEY` en plak de sleutel
   tussen de aanhalingstekens

### 2. Domein invullen
Bovenin `index.html` staan twee regels met `https://youfisystems.nl/`.
Klopt uw domein anders, pas ze dan beide aan:
- `<meta property="og:image" ...>`
- `<link rel="canonical" ...>`

### 3. Nog invullen in de tekst
- `[bedrag]` — 4 plaatsen (FAQ en de drie fases). Noem een richtprijs;
  geen prijs betekent voor de meeste ondernemers "te duur".
- Portretfoto — sectie "Over mij", formaat 1200 x 1500 px
- Een quote van Sloothaak of Friesland Begeleid Wonen
- Vestigingsplaats in de privacyverklaring (nu alleen "Nederland")

### 4. Toestemming
Controleer of u Friesland Begeleid Wonen en Sloothaak Bouwbeheer
bij naam mag noemen. In de screenshots zijn alle klantnamen,
adressen, telefoonnummers en e-mailadressen onherkenbaar gemaakt.

## Techniek
- Eén HTML-bestand met acht pagina's (routing via `#/pagina`)
- Geen frameworks, geen build-stap, geen cookies, geen analytics
- 160 KB HTML + 386 KB afbeeldingen, die pas laden wanneer nodig
- `prefers-reduced-motion` wordt overal gerespecteerd
- Werkt op iedere host: Vercel, Netlify, GitHub Pages of FTP
